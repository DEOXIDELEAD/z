// External cheat main logic
#include <Windows.h>

int main() { return 0; }
