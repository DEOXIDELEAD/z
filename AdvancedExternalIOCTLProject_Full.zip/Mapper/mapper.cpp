// Manual mapper to load the driver
#include <Windows.h>

int main() { return 0; }
