// GUI config editor
#include <iostream>

int main() { return 0; }
