// Kernel driver entry and IOCTL handler
#include <ntddk.h>

extern "C" NTSTATUS DriverEntry(...) { return STATUS_SUCCESS; }
