
#pragma once

#include <ntddk.h>

#define DEVICE_NAME L"\\Device\\MemoryAccess"
#define SYMLINK_NAME L"\\DosDevices\\MemoryAccess"

#define IOCTL_READ_MEMORY CTL_CODE(FILE_DEVICE_UNKNOWN, 0x666, METHOD_BUFFERED, FILE_SPECIAL_ACCESS)

typedef struct _KERNEL_READ_REQUEST {
    ULONG ProcessId;
    ULONG Address;
    SIZE_T Size;
    PVOID Response;
} KERNEL_READ_REQUEST, *PKERNEL_READ_REQUEST;

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath);
