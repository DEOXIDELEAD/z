
#include "driver.h"

PDEVICE_OBJECT g_DeviceObject = NULL;

NTSTATUS DispatchIoControl(PDEVICE_OBJECT DeviceObject, PIRP Irp) {
    PIO_STACK_LOCATION io = IoGetCurrentIrpStackLocation(Irp);
    ULONG code = io->Parameters.DeviceIoControl.IoControlCode;

    if (code == IOCTL_READ_MEMORY) {
        PKERNEL_READ_REQUEST req = (PKERNEL_READ_REQUEST)Irp->AssociatedIrp.SystemBuffer;
        PEPROCESS process;
        if (NT_SUCCESS(PsLookupProcessByProcessId((HANDLE)req->ProcessId, &process))) {
            SIZE_T bytes;
            MmCopyVirtualMemory(process, (PVOID)req->Address, PsGetCurrentProcess(), req->Response, req->Size, KernelMode, &bytes);
        }
    }

    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = sizeof(KERNEL_READ_REQUEST);
    IoCompleteRequest(Irp, IO_NO_INCREMENT);
    return STATUS_SUCCESS;
}

VOID UnloadDriver(PDRIVER_OBJECT DriverObject) {
    IoDeleteSymbolicLink(&SYMLINK_NAME);
    IoDeleteDevice(DriverObject->DeviceObject);
}

NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath) {
    UNREFERENCED_PARAMETER(RegistryPath);
    UNICODE_STRING devName = RTL_CONSTANT_STRING(DEVICE_NAME);
    UNICODE_STRING symLink = RTL_CONSTANT_STRING(SYMLINK_NAME);

    IoCreateDevice(DriverObject, 0, &devName, FILE_DEVICE_UNKNOWN, 0, FALSE, &g_DeviceObject);
    IoCreateSymbolicLink(&symLink, &devName);

    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DispatchIoControl;
    DriverObject->DriverUnload = UnloadDriver;
    return STATUS_SUCCESS;
}
